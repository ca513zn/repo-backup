const data = [
    {
        word: 'Net',
        definition: 'it can be used to catch fish or butterflies',
        
    }
]

export default data