import ThemeOptions from './reducers/theme-options';

export default {
    ThemeOptions
};