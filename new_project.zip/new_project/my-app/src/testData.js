const data = {
    auth: {
        auth: true,
        username: 'Carlos',
    }
}

export default data