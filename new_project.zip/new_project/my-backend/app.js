const bodyParser = require("body-parser");

const express = require("express");

const app = express();

const mongoose = require("mongoose");

const adminRoutes = require("./routes/admin");
const authRoutes = require("./routes/auth");
const shopRoutes = require("./routes/shop");
const userRoutes = require("./routes/user");

app.use(bodyParser.json());
require('dotenv').config()

app.use(bodyParser.urlencoded({ extended: true }));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-type, Authorization");
  next();
});

app.use("/admin", adminRoutes);
app.use("/auth", authRoutes);
app.use("/user", userRoutes);

app.use((req, res, next) => {
  res.status(404).send("<h1>404 page not found</h1>");
});

mongoose
  .connect(
    "mongodb+srv://admin:goonlive92@cluster0-uzuzy.mongodb.net/test?retryWrites=true&w=majority",
    {
      useUnifiedTopology: true,
      useNewUrlParser: true,
      useCreateIndex: true,
    }
  )
  .then((client) => {
    console.log("Database in use: " + client.connections[0].name);
    app.listen(3333);
  })
  .catch((err) => {
    console.log(err);
  });
