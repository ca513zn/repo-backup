const Product = require("../models/product");

exports.postAddProduct = (req, res, next) => {
  const title = req.body.title;
  const price = req.body.price;
  const description = req.body.description;
  const imageUrl = req.body.imageUrl;
  const categories = req.body.categories;

  const product = new Product({
    title: title,
    price: price,
    description: description,
    imageUrl: imageUrl,
    categories: categories,
  });

  product
    .save()
    .then((result) => {
      console.log(result);
      console.log("Product Created!");
      res.redirect("/admin/products");
    })
    .catch((e) => console.log("oops"));
};
