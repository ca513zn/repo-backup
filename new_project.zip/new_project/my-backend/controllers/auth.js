const User = require("../models/user");

const jwt = require("jwt-simple");
const bcrypt = require("bcrypt");

const errors = {
  user: "No such user exists.",
  password: "Incorrect password.",
};

const getToken = (params) => {
  const payload = {
    user: params,
  };
  const token = jwt.encode(payload, process.env.JWT_SECRET);
  return { token };
};

const comparePasswords = async (password, hashedPassword) => {
  return await bcrypt.compare(password, hashedPassword);
};

exports.login = async (req, res, next) => {
  const username = req.body.username;
  const password = req.body.password;

  try {
    //1. Check if the user exists
    const user = await User.findOne({$or: [{ username: username }, { email: username }]})  ;
    //2. If the user doesn't exist, return user error
    if(!user) {
      res.send({
        success: false,
        error: errors.user,
        token: null,
      });
      return;
    }
    //3. If the user exists, compare passwords
    else {
      if (password) {
        const loginSuccess = await comparePasswords(password, user.password);
        if (loginSuccess) {
          const user = await User.findOne(
            { $or: [{ username: username }, { email: username }] },
            "-password -__v -likes"
          );
          const token = getToken(await user);
          res.status(200).send({
            success: true,
            user: user,
            ...token,
          });
        } else {
          res.status(401).send({
            success: false,
            error: errors.password,
            token: null,
          });
          return;
        }
      } else {
        res.status(401).send({
          success: false,
          error: errors.password,
          token: null,
        });
        return;
      }
    }
  }
  catch(e) {
    console.log(e)
  }
};
