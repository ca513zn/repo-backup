const Lesson = require("../models/lesson");
const checkAuth = require('../middleware/check-auth')

exports.createLesson = (req, res, next) => {
  const lesson = {
    id: req.body.id,
    name: req.body.name,
    diamonds: req.body.diamonds,
    exp: req.body.exp,

  }
  const id = req.body.id;
  const name = req.body.name;
  const diamonds = req.body.diamonds;
  const exp = req.body.exp;

  const newLesson = new Lesson({
    name: name,
    gold: gold,
    diamonds: diamonds,
    exp: exp,
  });
  Lesson
    .save()
    .then((result) => {
      console.log("Product Created!");
      res.redirect("/admin/products");
    })
    .catch((e) => console.log("oops"));
};
