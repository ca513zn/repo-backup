const User = require("../models/user");
const bcrypt = require("bcrypt");

const saltRounds = 12;

const hashPass = async (password, salt) => {
  return await bcrypt.hash(password, salt);
};

const errors = {
  required: (field) => `${field} is required`,
};

exports.docCreate = async (req, res, next) => {
  if (!req.body.firstName) return res.send(errors.required("firstName"));
  if (!req.body.lastName) return res.send(errors.required("lastName"));
  if (!req.body.username) return res.send(errors.required("username"));
  if (!req.body.email) return res.send(errors.required("email"));
  if (!req.body.password) return res.send(errors.required("password"));
  if (!req.body.likes) return res.send(errors.required("likes"));
  if (!req.body.spiritAnimal) return res.send(errors.required("spiritAnimal"));
  const salt = await bcrypt.genSalt(saltRounds);
  const hashedPass = await hashPass(req.body.password, salt);
  const data = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    username: req.body.username,
    email: req.body.email,
    password: hashedPass,
    likes: req.body.likes,
    spiritAnimal: req.body.spiritAnimal,
  };
  const document = new User(data);
  document
    .save()
    .then((result) => {
      res.status(201).send({
        success: true,
        result: result,
      });
    })
    .catch((e) => {
      if (e.code === 11000) {
        res.send({
          success: false,
          error: 'Duplicate Key Error!',
          duplicateKey: e.keyValue
        });
        return
      }
      res.send({
        success: false,
        error: e,
      });
    });
};

exports.docRead = (req, res, next) => {
  if (!req.query.id) {
    res.send({
      success: false,
      error: "NO ID PROVIDED",
    });
    return;
  }

  User.findById(req.query.id)
    .then((result) => {
      res.status(200).send({
        success: true,
        user: result,
      });
    })
    .catch((e) => {
      res.send({
        success: false,
        error: e,
      });
    });
};

exports.docList = (req, res, next) => {
  User.find()
    .then((result) => {
      res.status(200).send({
        success: true,
        users: result,
      });
    })
    .catch((e) => {
      res.send({
        success: false,
        error: e,
      });
    });
};

exports.docUpdate = (req, res, next) => {
  const data = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
    likes: req.body.likes,
    spirit_animal: req.body.spirit_animal,
    skill: req.body.skill,
    cash: req.body.cash,
  };
  User.findOneAndUpdate(
    { _id: req.body.id },
    {
      $set: {
        ...data,
      },
    }
  )
    .then((result) => {
      res.status(201).send({
        success: true,
      });
    })
    .catch((e) => {
      res.send({
        success: false,
        error: e,
      });
    });
};

exports.docDelete = (req, res, next) => {
  try {
    req.body.id;
  } catch (e) {
    res.send({
      success: false,
      error: "NO ID PROVIDED: " + e,
    });
  }
  User.findByIdAndDelete(req.body.id)
    .then((result) => {
      res.status(200).send({
        success: true,
      });
    })
    .catch((e) => {
      res.send({
        success: false,
        error: e,
      });
    });
};
