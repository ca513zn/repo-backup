const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const lessonSchema = new Schema({
  name: { type: String, required: true },
  gold: { type: Number, required: true },
  diamonds: { type: Number, required: true },
  brain: { type: Number, required: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  minimum: { type: Number, required: true },
  timeLimit: { type: Number, required: true },
  questions: [
    {

    }
  ]
});

module.exports = mongoose.model("Lesson", lessonSchema);
