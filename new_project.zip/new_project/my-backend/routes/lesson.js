const express = require("express");

const router = express.Router();

const adminController = require("../controllers/admin");

// /admin/add-product
router.post("/lesson/preview", adminController.lessonGetPreview);

module.exports = router;