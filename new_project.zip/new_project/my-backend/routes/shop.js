const express = require('express')

const router = express.Router()

router.get('/store', (req, res, next) => {
    res.send('<h1>Welcome to the store ass</h1>')
})

module.exports = router