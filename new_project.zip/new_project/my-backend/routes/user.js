const express = require("express");

const router = express.Router();

const controller = require("../controllers/user");

router.post("/create", controller.docCreate);
router.get("/read", controller.docRead);
router.get("/list", controller.docList);
router.post("/update", controller.docUpdate);
router.post("/delete", controller.docDelete);

module.exports = router;
